import BrandService from "../Brands/BrandService";
import "./Services.css";
import "../Brands/Brands.css";

const Services = () => {
  return (
   <section className="services-section">
  <div className="bg-wrapper">
    <img src="/Bg.png" alt="bg" className="Bg-img" />
    <div className="services-container">
      <h1 className="services-text">Services</h1>
      <p className="title-desc">
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit
        tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.
      </p>
    </div>
  </div>

  <div className="brand-service-wrapper">
    <BrandService />
  </div>
</section>

  );
};

export default Services;
