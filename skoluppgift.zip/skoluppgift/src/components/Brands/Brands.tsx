import './Brands.css';
import BrandService from './BrandService';




const Brands = () => {
  const brands = [
    { id: 1, name: 'Brand 1', logo: '/Logoipsum 1.png' },
    { id: 2, name: 'Brand 2', logo: '/Logoipsum 2.png' },
    { id: 3, name: 'Brand 3', logo: '/Logoipsum 3.png' },
    { id: 4, name: 'Brand 4', logo: '/Logoipsum 4.png' },
    { id: 5, name: 'Brand 5', logo: '/Logoipsum 5.png' },
  ];

  return (
      <section className="brands-section">
        <div className="brands-container">
          <div className="brands-grid">
            {brands.map((brand) => (
              <div key={brand.id} className="brand-item">
                <img src={brand.logo} alt={brand.name} className="brand-logo" />
              </div>
            ))}
          </div>
        </div>
        <BrandService />
      </section>

  );
};

export default Brands;