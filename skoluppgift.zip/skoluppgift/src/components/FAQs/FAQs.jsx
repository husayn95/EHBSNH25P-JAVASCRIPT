import React, { useEffect, useState } from "react";

export async function getFAQs(url = "/api/faqs", { signal, headers } = {}) {
    const res = await fetch(url, {
        method: "GET",
        headers: { "Content-Type": "application/json", ...(headers || {}) },
        signal,
    });

    if (!res.ok) {
        const text = await res.text().catch(() => null);
        throw new Error(text || res.statusText || `Request failed (${res.status})`);
    }

    return res.json();
}

/**
 * FAQs component that demonstrates using getFAQs.
 */
export default function FAQs({ url = "/api/faqs" }) {
    const [faqs, setFaqs] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const controller = new AbortController();
        setLoading(true);
        setError(null);

        getFAQs(url, { signal: controller.signal })
            .then((data) => {
                // expect data to be an array of { question, answer } or similar
                setFaqs(Array.isArray(data) ? data : []);
            })
            .catch((err) => {
                if (err.name !== "AbortError") setError(err.message || "Failed to fetch");
            })
            .finally(() => setLoading(false));

        return () => controller.abort();
    }, [url]);

    if (loading) return <div>Loading FAQs...</div>;
    if (error) return <div style={{ color: "red" }}>Error: {error}</div>;
    if (!faqs.length) return <div>No FAQs available.</div>;

    return (
        <section>
            <h2>FAQs</h2>
            <ul>
                {faqs.map((f, i) => (
                    <li key={f.id ?? i}>
                        <strong>{f.question ?? f.q ?? "Question"}</strong>
                        <div>{f.answer ?? f.a ?? ""}</div>
                    </li>
                ))}
            </ul>
        </section>
    );
}