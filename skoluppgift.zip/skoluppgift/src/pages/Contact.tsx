function Contact() {
  return (
    <div>
      {/* <ContactHeader />
      <ContactForm />
      <FAQs />
      <Newsletter /> */}
    </div>
  );
}

export default Contact;
