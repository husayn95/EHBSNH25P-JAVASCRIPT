import AboutUs from "../components/AboutUs/AboutUs";


function About() {
  return (
    <div>
      {/* <AboutHeader />
      <AboutContent />
      <Testimonials />
      <Newsletter /> */}
      <AboutUs />
    </div>
  );
}

export default About;
