function Booking() {
  return (
    <div>
      {/* <BookingHeader />
      <BookingForm />
      <WhyChooseUs />
      <FAQs />
      <Newsletter /> */}
    </div>
  );
}

export default Booking;
