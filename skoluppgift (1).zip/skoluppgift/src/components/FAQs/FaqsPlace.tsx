import "./FaqsPlace.css";
import { useEffect, useState } from "react";

interface Faqs {
  id: string;
  created: string;
  title: string;
  description: string;
  imageUrl: string;
}

export default function FaqsPlace() {
  const [faqList, setFaqList] = useState<Faqs[]>([]);
  const [active, setActive] = useState<number | null>(null);

  const toggleAccordion = (index: number) => {
    setActive((prev) => (prev === index ? null : index));
  };

  useEffect(() => {
    const fetchFaqs = async () => {
      try {
        const response = await fetch(
          "https://win25-jsf-assignment.azurewebsites.net/api/faqs"
        );
        const data: Faqs[] = await response.json();
        setFaqList(data);
      } catch (error) {
        console.error("Failed to fetch faqs:", error);
      }
    };

    fetchFaqs();
  }, []);

  return (
    <section className="faq-section">
      <div className="faq-left">
        <p className="faq-tag">FAQs</p>
        <h2 className="faq-title">Frequently Ask Questions</h2>
        <p className="faq-desc">
          Here are the most common questions from our customers.
        </p>
      </div>

      <div className="faq-right">
        {faqList.map((faq, index) => (
          <div key={faq.id} className="faq-item">
            <button
              className={`faq-question ${active === index ? "active" : ""}`}
              onClick={() => toggleAccordion(index)}
            >
              {faq.title}
              <span className="arrow">{active === index ? "▲" : "▼"}</span>
            </button>

            {active === index && (
              <div className="faq-answer">{faq.description}</div>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}
