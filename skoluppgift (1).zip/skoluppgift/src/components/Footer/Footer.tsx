import "./Footer.css";

export default function Footer() {
  return (
    <>
      <section className="newsletter-section">
        <div className="newsletter-container">
          <div className="newsletter-text">
            <h2>Subscribe Our Newsletter</h2>
            <p>
              Subscribe to our newsletter to receive early discount offers, updates and info
            </p>
          </div>

          <form className="newsletter-form">
            <input type="email" placeholder="Enter your email *" required />
            <button type="submit">Submit</button>
          </form>
        </div>
      </section>

      <footer className="footer">
        <div className="footer-content">
          <p>© 2025 StorAid, All rights reserved.</p>

          <div className="footer-links">
            <a href="#">Terms & Conditions</a>
            <a href="#">Privacy Policy</a>
          </div>
        </div>
      </footer>
    </>
  );
}