import React from "react";
import "./AboutHeader.css";

export default function AboutHeader() {
  return (
    <div className="aboutHeader-container">
      <div className="aboutHeader-content">
        <h1 className="aboutHeader-title">About Us</h1>
        <p className="aboutHeader-description">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit
          tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.
        </p>
      </div>
    </div>
  );
}
