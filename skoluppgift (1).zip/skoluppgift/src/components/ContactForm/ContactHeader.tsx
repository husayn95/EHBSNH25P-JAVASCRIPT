import React from "react";
import "./ContactHeader.css";

export default function ContactHeader() {
  return (
    <div className="serviceHeader-container">
      <div className="serviceHeader-content">
        <h1 className="serviceHeader-title">Contact Us</h1>
        <p className="serviceHeader-description">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit
          tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.{" "}
        </p>
      </div>
    </div>
  );
}
