//Fick hjälp av AI att skapa ett kontaktformulär o validering

import { useState } from "react";
import "./Contactform.css";

export default function Contactform() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    telephone: "",
    subject: "",
    message: "",
  });

  const [errors, setErrors] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });

  const validate = () => {
    const temp: Partial<typeof errors> = {};

    if (!form.name.trim()) temp.name = "Name is required.";

    if (!form.email.trim()) temp.email = "Email is required.";
    else if (!/\S+@\S+\.\S+/.test(form.email))
      temp.email = "Invalid email format.";

    if (!form.subject.trim()) temp.subject = "Subject is required.";

    if (!form.message.trim()) temp.message = "Message is required.";

    setErrors(temp as typeof errors);

    return Object.keys(temp).length === 0;
  };
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      alert("Form submitted!");
    }
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  return (
    <section className="contact-section">
      <div className="contact-left">
        <p className="contacts-tag">Get in Touch</p>
        <h2 className="contacts-title">
          Get Personalized Assistance – Contact Us
        </h2>
        <p className="contact-desc">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit
          tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo
        </p>
        <div className="contact-image-placeholder"></div>
      </div>

      <form className="contact-form" onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Your Name *</label>
          <input
            name="name"
            type="text"
            placeholder="Your name"
            value={form.name}
            onChange={handleChange}
            className={errors.name ? "input-error" : ""}
          />
          {errors.name && <p className="error">{errors.name}</p>}
        </div>

        <div className="form-row">
          <div className="form-group">
            <label>Email *</label>
            <input
              name="email"
              type="email"
              placeholder="Email"
              value={form.email}
              onChange={handleChange}
              className={errors.email ? "input-error" : ""}
            />
            {errors.email && <p className="error">{errors.email}</p>}
          </div>

          <div className="form-group">
            <label>Telephone</label>
            <input
              name="telephone"
              type="text"
              placeholder="Telephone"
              value={form.telephone}
              onChange={handleChange}
            />
          </div>
        </div>

        <div className="form-group">
          <label>Subject *</label>
          <input
            name="subject"
            type="text"
            placeholder="How can we help you"
            value={form.subject}
            onChange={handleChange}
            className={errors.subject ? "input-error" : ""}
          />
          {errors.subject && <p className="error">{errors.subject}</p>}
        </div>

        <div className="form-group">
          <label>Comments / Questions *</label>
          <textarea
            name="message"
            placeholder="Comments"
            value={form.message}
            onChange={handleChange}
            className={errors.message ? "input-error" : ""}
          ></textarea>
          {errors.message && <p className="error">{errors.message}</p>}
        </div>

        <button className="submit-btn" type="submit">
          Submit
        </button>
      </form>
    </section>
  );
}
