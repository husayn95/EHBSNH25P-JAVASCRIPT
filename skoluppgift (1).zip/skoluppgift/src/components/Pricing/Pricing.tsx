import React from "react";
import "./Pricing.css";

const plans = [
  {
    name: "Small Unit",
    price: 50,
    color: "#E8F4DF", // light green
    dark: false,
    description: "Phasellus sollicitudin sapien eu massa accumsan, quis semper odio suscipit.",
  },
  {
    name: "Medium Unit",
    price: 100,
    color: "#092E23", // dark green
    dark: true,
    description: "Phasellus sollicitudin sapien eu massa accumsan, quis semper odio suscipit.",
  },
  {
    name: "Large Unit",
    price: 150,
    color: "#E8F4DF",
    dark: false,
    description: "Phasellus sollicitudin sapien eu massa accumsan, quis semper odio suscipit."
  },
  {
    name: "Executive Unit",
    price: 200,
    color: "#E8F4DF",
    dark: false,
    description: "Phasellus sollicitudin sapien eu massa accumsan, quis semper odio suscipit."
  },
];

const features = [
  "Nam nec ipsum in dolor",
  "Fusce nec ligula ut arcu",
  "Aliquam pulvinar arcu in",
  "Duis gravida enim porta",
  "Etiam eget libero non ligula",
];

const Pricing = () => {
  return (
    <section className="pricing-section">
      <p className="pricing-tag">Pricing Plan</p>
      <h2 className="pricing-title">
        Find the Perfect Plan for <br /> Your Storage Needs
      </h2>

      <div className="pricing-grid">
        {plans.map((plan, idx) => (
          <div
            key={idx}
            className={`pricing-card ${plan.dark ? "dark-card" : ""}`}
            style={{ background: plan.color }}
          >
            <h3 className={`plan-name ${plan.dark ? "dark-text" : ""}`}>
              {plan.name}
            </h3>
            <div className="price-box">
              <span className="dollar">$</span>
              <div className="price-month">
                <span className="price">{plan.price}</span>
                <span className={`per-month ${plan.dark ? "dark-text" : ""}`}>
                  /month
                </span>
              </div>
            </div>

            <p className={`plan-desc ${plan.dark ? "dark-text" : ""}`}>
                {plan.description}
            </p>

            <div className="divider"></div>

            <ul className="plan-features">
              {features.map((f, index) => (
                <li key={index}>
                  <span className="bullet"></span>
                  {f}
                </li>
              ))}
            </ul>

            <button className="rent-btn">Rent Now</button>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Pricing;
