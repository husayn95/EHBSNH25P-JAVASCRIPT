import React from "react";
import "./WhyChooseUs.css";

const WhyChooseUs = () => {
  return (
    <section className="why-choose-us">
      <div className="wcu-left">
        <p className="section-tag">Why Choose Us</p>

        <h2 className="section-title">
          Choose Us for Exceptional
          <br />
          Storage Solutions
        </h2>

        <div className="features-list">
          <div className="feature-row">
            <div className="feature-icon-wrapper">
              <img src="/lockIcon.png" className="feature-icon" />
            </div>
            <div>
              <h3 className="feature-title">Security and Safety</h3>
              <p className="feature-desc">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit
                tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.
              </p>
            </div>
          </div>

          <div className="feature-row">
            <div className="feature-icon-wrapper">
              <img src="/bagIcon.png" className="feature-icon" />
            </div>
            <div>
              <h3 className="feature-title">Flexible and Affordable</h3>
              <p className="feature-desc">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit
                tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.
              </p>
            </div>
          </div>

          <div className="feature-row">
            <div className="feature-icon-wrapper">
              <img src="/cleanIcon.png" className="feature-icon" />
            </div>
            <div>
              <h3 className="feature-title">
                Clean and Well-Maintained Facilities
              </h3>
              <p className="feature-desc">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit
                tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.
              </p>
            </div>
          </div>

          <div className="feature-row">
            <div className="feature-icon-wrapper">
              <img src="/clockIcon.png" className="feature-icon" />
            </div>
            <div>
              <h3 className="feature-title">24/7 and Convenient Access</h3>
              <p className="feature-desc">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit
                tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="wcu-right">
        <div className="right-top">
          <p className="right-paragraph">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque
            molestie nisl sed dui lacinia gravida. Nulla quis nulla leo. Mauris
            ac blandit nisi non sodales augue. Phasellus eget elit gravida.
          </p>
        </div>

        <img src="/Bgimg.png" className="right-image" />
      </div>
    </section>
  );
};

export default WhyChooseUs;
