
//Fick hjälp av AI för att lösa en del av detta


import "./OurService.css";

export default function OurServices() {
  const services = [
    {
      title: "Diverse Unit Sizes",
      description:
        "Lorem ipsum dolor sit amet, consectetur adipiscng elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.",
    },
    {
      title: "Moving Assistance",
      description:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.",
    },
    {
      title: "Vehicle Storage",
      description:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.",
    },
    {
      title: "Top-Notch Security",
      description:
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.",
    },
  ];

  return (
    <div className="container">
      <div className="wrapper">
        <div className="header">
          <p className="subtitle">Our Services</p>
          <div className="text-block">
            <h2 className="title">
              Specialized Storage for Every Special Item
            </h2>
            <p className="description">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque
              molestie nisl sed dui lacinia gravida. Nulla quis nulla leo.
              Mauris ac blandit nisi non sodales augue. Phasellus eget elit
              gravida.
            </p>
          </div>
        </div>

        <div className="services-grid">
          <div className="column">
            <div className="card card-normal">
              <h3 className="card-title">{services[0].title}</h3>
              <p className="card-description">{services[0].description}</p>
            </div>
            <div className="card card-normal">
              <h3 className="card-title">{services[1].title}</h3>
              <p className="card-description">{services[1].description}</p>
            </div>
          </div>

          <div className="greybox">
          </div>

          <div className="column">
            <div className="card card-normal">
              <h3 className="card-title">{services[2].title}</h3>
              <p className="card-description">{services[2].description}</p>
            </div>
            <div className="card card-normal">
              <h3 className="card-title">{services[3].title}</h3>
              <p className="card-description">{services[3].description}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
