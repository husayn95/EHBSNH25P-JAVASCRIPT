import React from 'react';
import './ServiceHeader.css';

export default function ServiceHeader() {
  return (
    <div className="serviceHeader-container">
      <div className="serviceHeader-content">
        <h1 className="serviceHeader-title">Services</h1>
        <p className="serviceHeader-description">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.
        </p>
      </div>
    </div>
  );
}