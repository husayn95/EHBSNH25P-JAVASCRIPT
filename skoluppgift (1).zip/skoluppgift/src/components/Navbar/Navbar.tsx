import {
  FaPhone,
  FaEnvelope,
  FaFacebookF,
  FaInstagram,
  FaYoutube,
} from "react-icons/fa";
import { FaXTwitter } from "react-icons/fa6";
import "./Navbar.css";
import { NavLink, useNavigate } from "react-router-dom";

export default function Navbar() {
  const navigate = useNavigate();
  return (
    <header className="navbar">
      <div className="top-bar">
        <div className="top-bar-left">
          <FaPhone /> <span>+46 8 123 122 44</span>
          <FaEnvelope /> <span>contact@domain.com</span>
        </div>

        <div className="top-bar-right">
          <div className="circle ">
            <FaFacebookF className="icon" />
          </div>
          <div className="circle ">
            <FaXTwitter className="icon" />
          </div>
          <div className="circle ">
            <FaInstagram className="icon" />
          </div>
          <div className="circle ">
            <FaYoutube className="icon" />
          </div>
        </div>
      </div>

      <div className="main-nav">
        <div className="logo">
          <img src="/Logo.png" alt="logo" />
        </div>

        <ul className="nav-links">
          <li className="navStyle">
            <NavLink
              to="/"
              style={({ isActive }) => ({
                textDecoration: "none",
                color: isActive ? "#F1C30C" : "inherit",
              })}
            >
              Home
            </NavLink>
          </li>
          <li className="navStyle">
            <NavLink
              to="/about"
              style={({ isActive }) => ({
                textDecoration: "none",
                color: isActive ? "#F1C30C" : "inherit",
              })}
            >
              About Us
            </NavLink>
          </li>
          <li className="navStyle">
            <NavLink
              to="/services"
              style={({ isActive }) => ({
                textDecoration: "none",
                color: isActive ? "#F1C30C" : "inherit",
              })}
            >
              Services
            </NavLink>
          </li>
          <li className="navStyle">
            <NavLink
              to="/contact"
              style={({ isActive }) => ({
                textDecoration: "none",
                color: isActive ? "#F1C30C" : "inherit",
              })}
            >
              Contact Us
            </NavLink>
          </li>
        </ul>

         <button className="book-btn" onClick={() => navigate('/booking')}>
          Book Now
        </button>
      </div>
    </header>
  );
}
