import { useEffect, useState } from "react";
import "./Blog.css";

interface BlogCard {
  id: string;
  created: string;
  title: string;
  description: string;
  imageUrl: string;
}

const BlogCards = () => {
  const [blog, setBlog] = useState<BlogCard[]>([]);

  useEffect(() => {
    const fetchBlogs = async () => {
      try {
        const response = await fetch(
          "https://win25-jsf-assignment.azurewebsites.net/api/blogs"
        );
        const data: BlogCard[] = await response.json();
        setBlog(data);
      } catch (error) {
        console.error("Failed to fetch blogs:", error);
      }
    };

    fetchBlogs();
  }, []);

  return (
    <div className="blogCards">
      {blog.map((item) => (
        <div key={item.id} className="blogCard">
          <img src={item.imageUrl} alt={item.title} />

          <div className="calender">
            <img src="/calenderIcon.png" alt="calendar" />
            <span className="date">
              {new Date(item.created).toLocaleDateString()}
            </span>
          </div>

          <div className="card-title">
            <p>{item.title}</p>
          </div>

          <div className="card-desc">
            <p>{item.description.substring(0, 150)}...</p>
          </div>

          <div className="read">
            <a href="#" className="read-more">
              Read more →
            </a>
          </div>
        </div>
      ))}
    </div>
  );
};

export default BlogCards;

// Fick hjälp av AI att fixa till API:et
