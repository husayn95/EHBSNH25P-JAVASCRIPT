import "./Blog.css";

import BlogCards from "./BlogCards";

const Blog = () => {
  return (
    <section className="blog-section">
      <div className="blog-container">
        <h4 className="blog-text">Latest Blog and News</h4>

        <div className="title-desc">
          <h3 className="blog-title">
            Check Out Our Latest Blog and News Update
          </h3>

          <p className="blog-description">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque
            molestie nisl sed dui lacinia gravida. Nulla quis nulla leo. Mauris
            ac blandit nisi non sodales augue. Phasellus eget elit gravida.
          </p>
        </div>

        <div className="blog-content">
          <div className="cards">
            <BlogCards />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Blog;
