import Cards from "./Cards";
import "./Testimonials.css";

const Testimonials = () => {
  return (
    <section className="testi-section">
      <img src="/worker.png" alt="bg" className="worker-img" />

      <div className="green-overlay"></div>

      <div className="testi-container">
        <div className="textTist-content">
          <h4 className="textTist-text">Testimonials</h4>

          <h3 className="testi-title">See What Our Client Have to Say</h3>

          <p className="testi-description">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque
            molestie nisl sed dui lacinia gravida. Nulla quis nulla leo. Mauris
            ac blandit nisi non sodales augue. Phasellus eget elit gravida.
          </p>
        </div>

        <div className="card-content">
          <div className="cards">
            <Cards />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
