import "./Testimonials.css";
import { useEffect, useState } from "react";

interface Testimonial {
  id: number;
  name: string;
  comment: string;
  rating: number;
  avatarUrl: string;
  companyName: string;
}

const Cards = () => {
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);

  useEffect(() => {
    const fetchTestimonials = async () => {
      try {
        const response = await fetch(
          "https://win25-jsf-assignment.azurewebsites.net/api/testimonials"
        );
        const data: Testimonial[] = await response.json();
        setTestimonials(data);
      } catch (error) {
        console.error("Failed to fetch testimonials:", error);
      }
    };

    fetchTestimonials();
  }, []);

  return (
    <div className="allcards">
      {testimonials.map((item) => (
        <div key={item.id} className="card">
          <div className="stars">
            {Array(item.rating)
              .fill(0)
              .map((_, i) => (
                <span key={i}>★</span>
              ))}
          </div>

          <p className="comment">{item.comment}</p>

          <div className="cardfooter">
            <div className="user-info">
              <img src={item.avatarUrl} alt={item.name} />
              <div className="user-details">
                <p className="user-name">{item.name}</p>
                <p className="user-title">{item.companyName}</p>
              </div>
            </div>

            <span className="quote-mark">
              <img src="/citat.png" alt="" />
            </span>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Cards;