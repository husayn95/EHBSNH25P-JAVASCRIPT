import "./Hero.css";

const Hero = () => {
  return (
    <section className="hero-section">
      <img src="/Bg.png" alt="background" className="background-img" />

      <div className="hero-container">
        <div className="hero-content">
          <div className="text-content">
            <h4 className="welcome-text">Welcome to StorAid</h4>

            <p className="hero-title">
              Space Simplified, <br /> Storage Perfected
            </p>

            <p className="hero-description">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean a sem magna. Etiam ac odio sit amet lorem fringilla sodales. Cras lobortis, libero at iaculis luctus, nisi ex pellentesque nisi, at euismod sem ipsum ac dolor.
            </p>

            <button className="cta-button">Get Started</button>
          </div>

          <div className="image-container">
            <img src="/humanimg.png" alt="person sitting" className="human-image" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;