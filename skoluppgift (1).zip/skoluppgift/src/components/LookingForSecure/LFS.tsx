import "./LFS.css";
import { useNavigate } from "react-router-dom";

const LFS = () => {
    const navigate = useNavigate();

  return (
    <section className="Lfs-section">
      <h2 className="Lfs-title">
        Looking for Secure and Flexible Storage? Find <br />
        Your Perfect Fit With Us.
      </h2>

      <p className="Lfs-text">
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque
        molestie nisl sed dui lacinia gravida. Nulla quis nulla leo. Mauris ac
        blandit nisi non sodales augue. Phasellus eget elit gravida.
      </p>

       <button className="Lfs-button" onClick={() => navigate('/booking')}>
          Book Now
        </button>
    </section>
  );
};

export default LFS;
