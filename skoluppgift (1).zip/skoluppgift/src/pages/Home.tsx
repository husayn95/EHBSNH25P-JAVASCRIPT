import AboutUs from "../components/AboutUs/AboutUs";
import Brands from "../components/Brands/Brands";
import WhyChooseUs from "../components/ChooseUs/WhyChooseUs";
import Hero from "../components/Hero/Hero";
import Blog from "../components/LatestBlog/Blog";
import LFS from "../components/LookingForSecure/LFS";
import Pricing from "../components/Pricing/Pricing";
import OurServices from "../components/Service/OurServices";
import Testimonials from "../components/Testimonials/Testimonials";

function Home() {
  return (
    <div>
      <Hero />

      <AboutUs />
      <Brands />
      <OurServices />
      <Testimonials />
      <WhyChooseUs />
      <Pricing />
      <LFS />
      <Blog />
    </div>
  );
}

export default Home;
