import FaqsPlace from "../components/FAQs/FaqsPlace";
import LFS from "../components/LookingForSecure/LFS";
import OurServices from "../components/Service/OurServices";
import ServiceHeader from "../components/Service/ServiceHeader";
import Testimonials from "../components/Testimonials/Testimonials";



function Services() {
  return (
    <div>
      <ServiceHeader />
    <OurServices />
    <Testimonials />
    <FaqsPlace/>
    <LFS/>
    </div>
  );
}

export default Services;
