import BookingContact from "../components/Booking/BookingContact";
import BookingHeader from "../components/Booking/BookingHeader";
import WhyChooseUs from "../components/ChooseUs/WhyChooseUs";
import FaqsPlace from "../components/FAQs/FaqsPlace";
import LFS from "../components/LookingForSecure/LFS";

function Booking() {
  return (
    <div>
     <BookingHeader />
     <BookingContact />
     <WhyChooseUs />
     <LFS />
     <FaqsPlace />
    </div>
  );
}

export default Booking;
