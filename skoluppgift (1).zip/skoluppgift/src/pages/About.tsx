import AboutHeader from "../components/AboutUs/AboutHeader";
import AboutUs from "../components/AboutUs/AboutUs";
import Brands from "../components/Brands/Brands";
import WhyChooseUs from "../components/ChooseUs/WhyChooseUs";
import Testimonials from "../components/Testimonials/Testimonials";

function About() {
  return (
    <div>
      {/* <AboutHeader />
      <AboutContent />
      <Testimonials />
      <Newsletter /> */}
      <AboutHeader />
      <AboutUs />
      <Brands />
      <Testimonials />
      <WhyChooseUs />
    </div>
  );
}

export default About;
