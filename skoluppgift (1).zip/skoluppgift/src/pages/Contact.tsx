import Contactform from "../components/ContactForm/Contactform";
import ContactHeader from "../components/ContactForm/ContactHeader";
import ContactSection from "../components/ContactForm/ContactSection";
import FaqsPlace from "../components/FAQs/FaqsPlace";

function Contact() {
  return (
    <div>
      <ContactHeader />
      <Contactform />
      <ContactSection />
      <FaqsPlace/>
    </div>
  );
}

export default Contact;
